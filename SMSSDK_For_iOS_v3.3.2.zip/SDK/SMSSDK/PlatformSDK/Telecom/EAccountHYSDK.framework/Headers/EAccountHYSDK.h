//
//  EAccountHYSDK.h
//  EAccountHYSDK
//
//  Created by lvzhzh on 2020/5/15.
//  Copyright © 2020 21cn. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EAccountOpenPageSDK.h"
#import "EAccountHYJSEventHandler.h"

//! Project version number for EAccountHYSDK.
FOUNDATION_EXPORT double EAccountHYSDKVersionNumber;

//! Project version string for EAccountHYSDK.
FOUNDATION_EXPORT const unsigned char EAccountHYSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EAccountHYSDK/PublicHeader.h>


