//
//  MobApm.h
//  MobApm
//
//  Created by maxl on 2020/7/2.
//  Copyright © 2020 mob. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MobApm : NSObject

//SDK版本
+ (NSString *)sdkVersion;

@end

NS_ASSUME_NONNULL_END
